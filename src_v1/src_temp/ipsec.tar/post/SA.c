#include "SA.h"

int seq_validate(SA* current_sa, uint32_t seq_num)
{
	//Seq# check by using sliding window

	return 0;
}

